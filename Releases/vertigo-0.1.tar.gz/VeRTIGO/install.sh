#!/bin/bash

if [ $# -ne 2 ]
then 
	echo "Usage: $0 [path where flowvisor.jar is located (/usr/local/libexec/flowvisor)] [path where envs.sh is located (/usr/local/etc/flowvisor)]"
	exit 1
fi

echo "Installing jar files in $1..."
cp -f *.jar $1
if [ $? -ne 0 ]
then
	echo "Error detected, exiting..."
	exit 1
fi

echo "Jar files installed"

echo "Installing envs.sh in $2 and copying original envs.sh in $2/envs.sh.old"
cp $2/envs.sh $2/envs.sh.old
if [ $? -ne 0 ]  
then
        echo "Error detected, exiting..."
        exit 1
fi

cp -f envs.sh $2
if [ $? -ne 0 ]
then
        echo "Error detected, exiting..."
        exit 1
fi

echo "Creating virtual link to VeRTIGO..."
fv_path=`which flowvisor`
fv_path_new=`dirname $fv_path`
cd $fv_path_new
ln -s flowvisor vertigo

echo "Installation completed with success!"
